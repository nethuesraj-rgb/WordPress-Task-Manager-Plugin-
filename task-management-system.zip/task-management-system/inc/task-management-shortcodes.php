<?php
   // Shortcode for login form
   add_shortcode('task_login', 'tms_login_shortcode');
   function tms_login_shortcode() {
       if (is_user_logged_in()) {
           return '<p class="text-center">You are already logged in. <a href="' . home_url('/task-dashboard') . '" class="text-blue-600">Go to Dashboard</a></p>';
       }
       ob_start();
       ?>
<div class="max-w-md mx-auto p-6 bg-white rounded-lg shadow-md">
   <h2 class="text-2xl font-bold mb-4 text-center"><?php _e('Login');?></h2>
   <form id="tms-login-form" class="space-y-4">
      <div>
         <label for="username" class="block text-sm font-medium"><?php _e('Username');?></label>
         <input type="text" id="username" name="username" required class="w-full p-2 border rounded-md">
      </div>
      <div>
         <label for="password" class="block text-sm font-medium"><?php _e('Password');?></label>
         <input type="password" id="password" name="password" required class="w-full p-2 border rounded-md">
      </div>
      <button type="submit" class="w-full bg-green-600 text-white p-2 px-4 rounded-md hover:bg-green-700"><?php _e('Login');?></button>
      <p id="tms-login-error" class="text-red-600 hidden"></p>
   </form>
</div>
<?php
   return ob_get_clean();
   }
   
   // Shortcode for logout button
   add_shortcode('task_logout', 'tms_logout_shortcode');
   function tms_logout_shortcode() {
   if (!is_user_logged_in()) {
       return '<p class="text-center">You are not logged in. <a href="' . home_url('/task-login') . '" class="text-blue-600">Login</a></p>';
   }
   $logout_url = wp_logout_url(home_url('/task-login'));
   error_log('TMS Logout URL: ' . $logout_url);
   return '<div class="text-center"><a href="' . esc_url($logout_url) . '" class="bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-700">Logout</a></div>';
   }
   
   // Shortcode for dashboard
   add_shortcode('task_dashboard', 'tms_dashboard_shortcode');
   function tms_dashboard_shortcode() {
   if (!is_user_logged_in()) {
       return '<p class="text-center">Please <a href="' . home_url('/task-login') . '" class="text-blue-600">login</a> to view your dashboard.</p>';
   }
   $user = wp_get_current_user();
   ob_start();
   ?>
<div class="max-w-4xl mx-auto p-6 bg-white rounded-lg shadow-md dashboard-links">
   <h2 class="text-2xl font-bold mb-4"><?php _e('Welcome,');?> <?php echo esc_html($user->display_name); ?></h2>
   <?php if (current_user_can('project_manager')): ?>
   <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
      <a href="<?php echo home_url('/task-user-list'); ?>" class="border border-green-600 text-black p-4 rounded-md flex gap-2 justify-center items-center transition-all duration-300 hover:bg-green-600 hover:text-white">
         <svg width="30" height="30" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M8 7C9.65685 7 11 5.65685 11 4C11 2.34315 9.65685 1 8 1C6.34315 1 5 2.34315 5 4C5 5.65685 6.34315 7 8 7Z" fill="currentColor"/>
            <path d="M14 12C14 10.3431 12.6569 9 11 9H5C3.34315 9 2 10.3431 2 12V15H14V12Z" fill="currentColor"/>
         </svg>
         <?php _e('Manage Users');?>
      </a>
      <a href="<?php echo home_url('/task-create-task'); ?>" class="border border-green-600 text-black p-4 rounded-md flex gap-2 justify-center items-center transition-all duration-300 hover:bg-green-600 hover:text-white">
         <svg width="30" height="30" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M11 6L21 6.00072M11 12L21 12.0007M11 18L21 18.0007M3 11.9444L4.53846 13.5L8 10M3 5.94444L4.53846 7.5L8 4M4.5 18H4.51M5 18C5 18.2761 4.77614 18.5 4.5 18.5C4.22386 18.5 4 18.2761 4 18C4 17.7239 4.22386 17.5 4.5 17.5C4.77614 17.5 5 17.7239 5 18Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
         </svg>
         <?php _e('Create Task');?>
      </a>
      <a href="<?php echo home_url('/task-all-tasks'); ?>" class="border border-green-600 text-black p-4 rounded-md flex gap-2 justify-center items-center transition-all duration-300 hover:bg-green-600 hover:text-white">
         <svg width="30" height="30" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M10 6L21 6.00066M10 12L21 12.0007M10 18L21 18.0007M3 5L5 4V10M5 10H3M5 10H7M7 20H3L6.41274 17.0139C6.78593 16.6873 7 16.2156 7 15.7197C7 14.7699 6.23008 14 5.28033 14H5C4.06808 14 3.28503 14.6374 3.06301 15.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
         </svg>
         <?php _e('All Tasks');?>
      </a>
   </div>
   <?php else: ?>
   <a href="<?php echo home_url('/task-my-tasks'); ?>" class="border border-green-600 text-black p-4 rounded-md flex gap-2 justify-center items-center transition-all duration-300 md:w-1/4 hover:bg-green-600 hover:text-white">
      <svg width="30" height="30" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
         <path d="M10 6L21 6.00066M10 12L21 12.0007M10 18L21 18.0007M3 5L5 4V10M5 10H3M5 10H7M7 20H3L6.41274 17.0139C6.78593 16.6873 7 16.2156 7 15.7197C7 14.7699 6.23008 14 5.28033 14H5C4.06808 14 3.28503 14.6374 3.06301 15.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
      <?php _e('My Tasks');?>
   </a>
   <?php endif; ?>
</div>
<?php
   return ob_get_clean();
   }
   
   // Shortcode for user list (PM only)
   add_shortcode('task_user_list', 'tms_user_list_shortcode');
function tms_user_list_shortcode() {
    if (!is_user_logged_in() || !current_user_can('project_manager')) {
        return '<p class="text-center">Access denied. <a href="' . home_url('/task-login') . '" class="text-blue-600">Login</a> as Project Manager.</p>';
    }
    $users = tms_get_users_by_role(['project_manager', 'team_member']);
    // Debug: Log the retrieved users
    error_log('TMS User List: Retrieved users - ' . print_r($users, true));
    ob_start();
    ?>
    <div class="max-w-4xl mx-auto p-6 bg-white rounded-lg shadow-md">
     <h2 class="text-2xl font-bold mt-8 mb-4"><?php _e('Create New User');?></h2>
        <form id="tms-create-user-form" class="space-y-4">
            <div>
         <label for="username" class="block text-sm font-medium pb-2"><?php _e('Username');?></label>
         <input type="text" id="username" name="username" required class="w-full p-2 border rounded-md">
      </div>
      <div>
         <label for="email" class="block text-sm font-medium pb-2"><?php _e('Email');?></label>
         <input type="email" id="email" name="email" required class="w-full p-2 border rounded-md">
      </div>
      <div>
         <label for="password" class="block text-sm font-medium pb-2"><?php _e('Password');?></label>
         <input type="password" id="password" name="password" required class="w-full p-2 border rounded-md">
      </div>
      <div>
         <label for="role" class="block text-sm font-medium pb-2"><?php _e('Role');?></label>
         <select id="role" name="role" required class="w-full p-2 border rounded-md">
            <option value="project_manager"><?php _e('Project Manager');?></option>
            <option value="team_member"><?php _e('Team Member');?></option>
         </select>
      </div>
      <button type="submit" class="bg-green-600 text-white p-2 px-4 rounded-md hover:bg-green-700"><?php _e('Create User');?></button>
      <p id="tms-user-message" class="mt-2 text-center hidden"></p>
      </form>
        <h2 class="text-2xl font-bold mt-8 mb-4"><?php _e('Existing Users');?></h2>
        <table class="w-full border-collapse text-base">
            <thead>
                <tr class="bg-gray-100">
                    <th class="border p-2"><?php _e('Username');?></th>
                    <th class="border p-2"><?php _e('Email');?></th>
                    <th class="border p-2"><?php _e('Role');?></th>
                    <th class="border p-2"><?php _e('Actions');?></th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($users) || !is_array($users)) : ?>
                    <tr>
                        <td colspan="4" class="border p-4 text-center text-gray-500"><?php _e('No users added here');?></td>
                    </tr>
                <?php else : ?>
                    <?php foreach ($users as $user) : ?>
                        <tr data-user-id="<?php echo esc_attr($user->ID); ?>">
                            <td class="border p-2"><?php echo esc_html($user->user_login); ?></td>
                            <td class="border p-2"><?php echo esc_html($user->user_email); ?></td>
                            <td class="border p-2"><?php echo esc_html($user->roles[0] ?? 'N/A'); ?></td>
                            <td class="border p-2">
                                <button class="tms-edit-user bg-yellow-500 text-white px-2 py-1 rounded hover:bg-yellow-600" 
                                        data-user-id="<?php echo esc_attr($user->ID); ?>" 
                                        data-username="<?php echo esc_attr($user->user_login); ?>" 
                                        data-email="<?php echo esc_attr($user->user_email); ?>" 
                                        data-role="<?php echo esc_attr($user->roles[0] ?? ''); ?>"><span class="screen-reader-text"><?php _e('Edit');?></span> 
                  <svg fill="#fff" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" 
                     width="12" height="12" viewBox="0 0 528.899 528.899"
                     xml:space="preserve">
                     <g>
                        <path d="M328.883,89.125l107.59,107.589l-272.34,272.34L56.604,361.465L328.883,89.125z M518.113,63.177l-47.981-47.981
                           c-18.543-18.543-48.653-18.543-67.259,0l-45.961,45.961l107.59,107.59l53.611-53.611
                           C532.495,100.753,532.495,77.559,518.113,63.177z M0.3,512.69c-1.958,8.812,5.998,16.708,14.811,14.565l119.891-29.069
                           L27.473,390.597L0.3,512.69z"/>
                     </g>
                  </svg></button>
                                <button class="tms-delete-user bg-red-600 text-white px-2 py-1 rounded hover:bg-red-700" 
                                        data-user-id="<?php echo esc_attr($user->ID); ?>"><span class="screen-reader-text"><?php _e('Delete');?></span>
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                     <path d="M6.99486 7.00636C6.60433 7.39689 6.60433 8.03005 6.99486 8.42058L10.58 12.0057L6.99486 15.5909C6.60433 15.9814 6.60433 16.6146 6.99486 17.0051C7.38538 17.3956 8.01855 17.3956 8.40907 17.0051L11.9942 13.4199L15.5794 17.0051C15.9699 17.3956 16.6031 17.3956 16.9936 17.0051C17.3841 16.6146 17.3841 15.9814 16.9936 15.5909L13.4084 12.0057L16.9936 8.42059C17.3841 8.03007 17.3841 7.3969 16.9936 7.00638C16.603 6.61585 15.9699 6.61585 15.5794 7.00638L11.9942 10.5915L8.40907 7.00636C8.01855 6.61584 7.38538 6.61584 6.99486 7.00636Z" fill="#fff"/>
                  </svg></button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
        <!-- Edit User Modal -->
        <div id="tms-edit-user-modal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden flex items-center justify-center z-40">
            <div class="bg-white p-6 rounded-lg shadow-md max-w-md w-full">
                <h3 class="text-xl font-bold mb-4"><?php _e('Edit User');?></h3>
                <form id="tms-edit-user-form" class="space-y-4">
                    <input type="hidden" id="edit-user-id" name="user_id">
                    <div>
                        <label for="edit-username" class="block text-sm font-medium pb-2"><?php _e('Username');?></label>
                        <input type="text" id="edit-username" name="username" required class="w-full p-2 border rounded-md">
                    </div>
                    <div>
                        <label for="edit-email" class="block text-sm font-medium pb-2"><?php _e('Email');?></label>
                        <input type="email" id="edit-email" name="email" required class="w-full p-2 border rounded-md">
                    </div>
                    <div>
                        <label for="edit-password" class="block text-sm font-medium pb-2"><?php _e('Password (leave blank to keep unchanged)');?></label>
                        <input type="password" id="edit-password" name="password" class="w-full p-2 border rounded-md">
                    </div>
                    <div>
                        <label for="edit-role" class="block text-sm font-medium pb-2"><?php _e('Role');?></label>
                        <select id="edit-role" name="role" required class="w-full p-2 border rounded-md">
                            <option value="project_manager"><?php _e('Project Manager');?></option>
                            <option value="team_member"><?php _e('Team Member');?></option>
                        </select>
                    </div>
                    <div class="flex justify-end space-x-2">
                        <button type="button" id="tms-cancel-edit-user" class="bg-gray-500 text-white p-2 px-4 rounded-md hover:bg-gray-600"><?php _e('Cancel');?></button>
                        <button type="submit" class="bg-blue-600 text-white p-2 px-4 rounded-md hover:bg-blue-700"><?php _e('Update User');?></button>
                    </div>
                    <p id="tms-edit-user-message" class="mt-2 text-center hidden"></p>
                </form>
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
   
   // Shortcode for create task (PM only)
   add_shortcode('task_create_task', 'tms_create_task_shortcode');
   function tms_create_task_shortcode() {
   if (!is_user_logged_in() || !current_user_can('project_manager')) {
       return '<p class="text-center">Access denied. <a href="' . home_url('/task-login') . '" class="text-blue-600">Login</a> as Project Manager.</p>';
   }
   ob_start();
   ?>
<div class="max-w-4xl mx-auto p-6 bg-white rounded-lg shadow-md">
   <h2 class="text-2xl font-bold mb-4"><?php _e('Create Task');?></h2>
   <form id="tms-create-task-form" class="space-y-4">
      <div>
         <label for="title" class="block text-sm font-medium pb-2"><?php _e('Task Title');?></label>
         <input type="text" id="title" name="title" required class="w-full p-2 border rounded-md">
      </div>
      <div>
         <label for="description" class="block text-sm font-medium pb-2"><?php _e('Description');?></label>
         <textarea id="description" name="description" class="w-full p-2 border rounded-md"></textarea>
      </div>
      <div>
         <label for="assigned_to" class="block text-sm font-medium pb-2"><?php _e('Assign To');?></label>
         <select id="assigned_to" name="assigned_to" required class="w-full p-2 border rounded-md">
         <?php
            $users = tms_get_users_by_role('team_member');
            foreach ($users as $user) {
                echo '<option value="' . $user->ID . '">' . esc_html($user->user_login) . '</option>';
            }
            ?>
         </select>
      </div>
      <div>
         <label for="status" class="block text-sm font-medium pb-2"><?php _e('Status');?></label>
         <select id="status" name="status" required class="w-full p-2 border rounded-md">
            <option value="open"><?php _e('Open');?></option>
            <option value="in-progress"><?php _e('In Progress');?></option>
            <option value="in-review"><?php _e('In Review');?></option>
            <option value="pending"><?php _e('Pending');?></option>
            <option value="completed"><?php _e('Completed');?></option>
         </select>
      </div>
      <div>
         <button type="submit" class="bg-green-600 text-white p-2 px-4 rounded-md hover:bg-green-700">Create Task</button>
         <p id="tms-task-message" class="mt-2 text-center hidden"></p>
      </div>
   </form>
</div>
<?php
   return ob_get_clean();
   }
   
   // Shortcode for all tasks (PM only)
   add_shortcode('task_all_tasks', 'tms_all_tasks_shortcode');
function tms_all_tasks_shortcode() {
    if (!is_user_logged_in() || !current_user_can('project_manager')) {
        return '<p class="text-center">Access denied. <a href="' . home_url('/task-login') . '" class="text-blue-600">Login</a> as Project Manager.</p>';
    }
    $tasks = tms_get_user_tasks(get_current_user_id(), true);
    ob_start();
    ?>
    <div class="max-w-4xl mx-auto p-6 bg-white rounded-lg shadow-md">
        <h2 class="text-2xl font-bold mb-4"><?php _e('All Tasks');?></h2>
        <table class="w-full border-collapse text-base">
            <thead>
                <tr class="bg-gray-100">
                     <th class="border p-2"><?php _e('Title');?></th>
                     <th class="border p-2"><?php _e('Description');?></th>
                     <th class="border p-2"><?php _e('Assigned To');?></th>
                     <th class="border p-2"><?php _e('Status');?></th>
                     <th class="border p-2"><?php _e('Actions');?></th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($tasks)) : ?>
                    <tr>
                        <td colspan="5" class="border p-4 text-center text-gray-500"><?php _e('No tasks added here');?></td>
                    </tr>
                <?php else : ?>
                    <?php foreach ($tasks as $task) : ?>
                        <tr data-task-id="<?php echo esc_attr($task->id); ?>">
                            <td class="border p-2"><?php echo esc_html($task->title); ?></td>
                            <td class="border p-2"><?php echo esc_html($task->description); ?></td>
                            <td class="border p-2">
                                <?php
                                $assigned_user = get_user_by('ID', $task->assigned_to);
                                echo $assigned_user ? esc_html($assigned_user->user_login) : 'Unassigned';
                                ?>
                            </td>
                            <td class="border p-2">
                                <select class="tms-update-status status-<?php echo esc_attr($task->status); ?>" data-task-id="<?php echo esc_attr($task->id); ?>">
                                    <option value="open" <?php selected($task->status, 'open'); ?>><?php _e('Open');?></option>
                                    <option value="in-progress" <?php selected($task->status, 'in-progress'); ?>><?php _e('In Progress');?></option>
                                    <option value="in-review" <?php selected($task->status, 'in-review'); ?>><?php _e('In Review');?></option>
                                    <option value="pending" <?php selected($task->status, 'pending'); ?>><?php _e('Pending');?></option>
                                    <option value="completed" <?php selected($task->status, 'completed'); ?>><?php _e('Completed');?></option>
                                </select>
                                <p id="tms-task-message-<?php echo esc_attr($task->id); ?>" class="mt-2 text-center hidden"></p>
                            </td>
                            <td class="border p-2">
                                <button class="tms-edit-task bg-yellow-500 text-white px-2 py-1 rounded hover:bg-yellow-600" 
                                        data-task-id="<?php echo esc_attr($task->id); ?>" 
                                        data-title="<?php echo esc_attr($task->title); ?>" 
                                        data-description="<?php echo esc_attr($task->description); ?>" 
                                        data-assigned-to="<?php echo esc_attr($task->assigned_to); ?>" 
                                        data-status="<?php echo esc_attr($task->status); ?>"><span class="screen-reader-text"><?php _e('Edit');?></span> 
                  <svg fill="#fff" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" 
                     width="12" height="12" viewBox="0 0 528.899 528.899"
                     xml:space="preserve">
                     <g>
                        <path d="M328.883,89.125l107.59,107.589l-272.34,272.34L56.604,361.465L328.883,89.125z M518.113,63.177l-47.981-47.981
                           c-18.543-18.543-48.653-18.543-67.259,0l-45.961,45.961l107.59,107.59l53.611-53.611
                           C532.495,100.753,532.495,77.559,518.113,63.177z M0.3,512.69c-1.958,8.812,5.998,16.708,14.811,14.565l119.891-29.069
                           L27.473,390.597L0.3,512.69z"/>
                     </g>
                  </svg></button>
                                <button class="tms-delete-task bg-red-600 text-white px-2 py-1 rounded hover:bg-red-700" 
                                        data-task-id="<?php echo esc_attr($task->id); ?>"><span class="screen-reader-text"><?php _e('Delete');?></span> 
                 <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                     <path d="M6.99486 7.00636C6.60433 7.39689 6.60433 8.03005 6.99486 8.42058L10.58 12.0057L6.99486 15.5909C6.60433 15.9814 6.60433 16.6146 6.99486 17.0051C7.38538 17.3956 8.01855 17.3956 8.40907 17.0051L11.9942 13.4199L15.5794 17.0051C15.9699 17.3956 16.6031 17.3956 16.9936 17.0051C17.3841 16.6146 17.3841 15.9814 16.9936 15.5909L13.4084 12.0057L16.9936 8.42059C17.3841 8.03007 17.3841 7.3969 16.9936 7.00638C16.603 6.61585 15.9699 6.61585 15.5794 7.00638L11.9942 10.5915L8.40907 7.00636C8.01855 6.61584 7.38538 6.61584 6.99486 7.00636Z" fill="#fff"/>
                  </svg></button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
        <!-- Edit Task Modal -->
        <div id="tms-edit-task-modal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden flex items-center justify-center z-40">
            <div class="bg-white p-6 rounded-lg shadow-md max-w-md w-full">
                <h3 class="text-xl font-bold mb-4"><?php _e('Edit Task');?></h3>
                <form id="tms-edit-task-form" class="space-y-4">
                    <input type="hidden" id="edit-task-id" name="task_id">
                    <div>
                        <label for="edit-title" class="block text-sm font-medium pb-2"><?php _e('Task Title');?></label>
                        <input type="text" id="edit-title" name="title" required class="w-full p-2 border rounded-md">
                    </div>
                    <div>
                        <label for="edit-description" class="block text-sm font-medium pb-2"><?php _e('Description');?></label>
                        <textarea id="edit-description" name="description" class="w-full p-2 border rounded-md"></textarea>
                    </div>
                    <div>
                        <label for="edit-assigned-to" class="block text-sm font-medium pb-2"><?php _e('Assign To');?></label>
                        <select id="edit-assigned-to" name="assigned_to" required class="w-full p-2 border rounded-md">
                            <?php
                            $users = tms_get_users_by_role('team_member');
                            foreach ($users as $user) {
                                echo '<option value="' . esc_attr($user->ID) . '">' . esc_html($user->user_login) . '</option>';
                            }
                            ?>
                        </select>
                    </div>
                    <div>
                        <label for="edit-status" class="block text-sm font-medium pb-2"><?php _e('Status');?></label>
                        <select id="edit-status" name="status" required class="w-full p-2 border rounded-md">
                              <option value="open"><?php _e('Open');?></option>
                              <option value="in-progress"><?php _e('In Progress');?></option>
                              <option value="in-review"><?php _e('In Review');?></option>
                              <option value="pending"><?php _e('Pending');?></option>
                              <option value="completed"><?php _e('Completed');?></option>
                        </select>
                    </div>
                    <div class="flex justify-end space-x-2">
                        <button type="button" id="tms-cancel-edit-task" class="bg-gray-500 text-white p-2 px-4 rounded-md hover:bg-gray-600"><?php _e('Cancel');?></button>
                        <button type="submit" class="bg-blue-600 text-white p-2 px-4 rounded-md hover:bg-blue-700"><?php _e('Update Task');?></button>
                    </div>
                    <p id="tms-edit-task-message" class="mt-2 text-center hidden"></p>
                </form>
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
   
   // Shortcode for my tasks (Team Members)
   add_shortcode('task_my_tasks', 'tms_my_tasks_shortcode');
function tms_my_tasks_shortcode() {
    if (!is_user_logged_in()) {
        return '<p class="text-center">Access denied. <a href="' . home_url('/task-login') . '" class="text-blue-600">Login</a> to continue.</p>';
    }
    $tasks = tms_get_user_tasks(get_current_user_id());
    ob_start();
    ?>
    <div class="max-w-4xl mx-auto p-6 bg-white rounded-lg shadow-md">
        <h2 class="text-2xl font-bold mb-4"><?php _e('My Tasks');?></h2>
        <table class="w-full border-collapse text-base">
            <thead>
                <tr class="bg-gray-100">
                     <th class="border p-2"><?php _e('Title');?></th>
                     <th class="border p-2"><?php _e('Description');?></th>
                     <th class="border p-2"><?php _e('Status');?></th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($tasks)) : ?>
                    <tr>
                        <td colspan="3" class="border p-4 text-center text-gray-500"><?php _e('No tasks added here');?></td>
                    </tr>
                <?php else : ?>
                    <?php foreach ($tasks as $task) : ?>
                        <tr data-task-id="<?php echo esc_attr($task->id); ?>">
                            <td class="border p-2"><?php echo esc_html($task->title); ?></td>
                            <td class="border p-2"><?php echo esc_html($task->description); ?></td>
                            <td class="border p-2">
                                <select class="tms-update-status status-<?php echo esc_attr($task->status); ?>" data-task-id="<?php echo esc_attr($task->id); ?>">
                                    <option value="open" <?php selected($task->status, 'open'); ?>><?php _e('Open');?></option>
                                    <option value="in-progress" <?php selected($task->status, 'in-progress'); ?>><?php _e('In Progress');?></option>
                                    <option value="in-review" <?php selected($task->status, 'in-review'); ?>><?php _e('In Review');?></option>
                                   <option value="pending" <?php selected($task->status, 'pending'); ?>><?php _e('Pending');?></option>
                                   <option value="completed" <?php selected($task->status, 'completed'); ?>><?php _e('Completed');?></option>                                </select>
                                <p id="tms-task-message-<?php echo esc_attr($task->id); ?>" class="mt-2 text-center hidden"></p>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php
    return ob_get_clean();
}
   ?>