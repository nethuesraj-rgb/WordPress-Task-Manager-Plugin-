<?php
// Login function
function tms_login_user($username, $password) {
    $creds = [
        'user_login' => $username,
        'user_password' => $password,
        'remember' => true,
    ];
    $user = wp_signon($creds, false);
    if (is_wp_error($user)) {
        error_log('TMS Login Error: ' . $user->get_error_message());
        return ['success' => false, 'data' => ['message' => $user->get_error_message()]];
    }
    wp_set_current_user($user->ID);
    wp_set_auth_cookie($user->ID);
    $redirect_url = home_url('/task-dashboard');
    error_log('TMS Login Success: Redirecting to ' . $redirect_url);
    return ['success' => true, 'data' => ['redirect' => $redirect_url]];
}

// Create user function
function tms_create_user($username, $email, $password, $role) {
    if (username_exists($username) || email_exists($email)) {
        return ['success' => false, 'message' => 'Username or email already exists.'];
    }
    $user_id = wp_create_user($username, $password, $email);
    if (is_wp_error($user_id)) {
        return ['success' => false, 'message' => $user_id->get_error_message()];
    }
    $user = new WP_User($user_id);
    $user->set_role($role);
    return ['success' => true, 'message' => 'User created successfully.'];
}

// Create task function
function tms_create_task($title, $description, $assigned_to, $status, $created_by) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'tms_tasks';
    $result = $wpdb->insert(
        $table_name,
        [
            'title' => $title,
            'description' => $description,
            'status' => $status,
            'assigned_to' => $assigned_to,
            'created_by' => $created_by,
        ],
        ['%s', '%s', '%s', '%d', '%d']
    );
    if ($result === false) {
        return ['success' => false, 'message' => 'Failed to create task.'];
    }
    return ['success' => true, 'message' => 'Task created successfully.'];
}

// Update task status
function tms_update_task_status($task_id, $status, $user_id) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'tms_tasks';
    
    // Check if task exists
    $task = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $task_id));
    if (!$task) {
        error_log('TMS Update Task Status: Task not found');
        return ['success' => false, 'data' => ['message' => 'Task not found.']];
    }
    
    // Restrict to Project Managers or the assigned user
    if (!current_user_can('project_manager') && $task->assigned_to != $user_id) {
        error_log('TMS Update Task Status: Unauthorized');
        return ['success' => false, 'data' => ['message' => 'Unauthorized to update this task.']];
    }
    
    // Update task status
    $result = $wpdb->update(
        $table_name,
        ['status' => $status],
        ['id' => $task_id],
        ['%s'],
        ['%d']
    );
    if ($result === false) {
        error_log('TMS Update Task Status: Database error');
        return ['success' => false, 'data' => ['message' => 'Failed to update task status.']];
    }
    return ['success' => true, 'data' => ['message' => 'Task status updated successfully.']];
}

// Get all users by role
function tms_get_users_by_role($roles = []) {
    $args = [
        'role__in' => is_array($roles) ? $roles : [$roles],
        'fields' => 'all',
    ];
    $users = get_users($args);
    // Debug: Log the query and results
    error_log('TMS Get Users By Role: Roles - ' . print_r($roles, true));
    error_log('TMS Get Users By Role: Retrieved users - ' . print_r($users, true));
    return $users;
}

// Get tasks by user
function tms_get_user_tasks($user_id, $is_pm = false) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'tms_tasks';
    if ($is_pm) {
        return $wpdb->get_results("SELECT * FROM $table_name ORDER BY created_at DESC");
    }
    return $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_name WHERE assigned_to = %d ORDER BY created_at DESC", $user_id));
}
?>