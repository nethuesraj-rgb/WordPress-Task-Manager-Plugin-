<?php
// AJAX handler for user login
add_action('wp_ajax_tms_login', 'tms_ajax_login');
add_action('wp_ajax_nopriv_tms_login', 'tms_ajax_login');
function tms_ajax_login() {
    error_log('TMS Login AJAX called with POST: ' . print_r($_POST, true));
    
    if (!check_ajax_referer('tms_nonce', 'nonce', false)) {
        error_log('TMS Login: Nonce verification failed');
        wp_send_json(['success' => false, 'data' => ['message' => 'Security check failed. Please try again.']]);
        return;
    }
    
    $username = sanitize_text_field($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (empty($username) || empty($password)) {
        error_log('TMS Login: Missing username or password');
        wp_send_json(['success' => false, 'data' => ['message' => 'Username and password are required.']]);
        return;
    }
    
    $result = tms_login_user($username, $password);
    error_log('TMS Login Result: ' . print_r($result, true));
    wp_send_json($result);
}

// AJAX handler for creating a new user
add_action('wp_ajax_tms_create_user', 'tms_ajax_create_user');
function tms_ajax_create_user() {
    error_log('TMS Create User AJAX called with POST: ' . print_r($_POST, true));
    
    if (!current_user_can('project_manager')) {
        error_log('TMS Create User: Unauthorized');
        wp_send_json(['success' => false, 'data' => ['message' => 'Unauthorized']]);
        return;
    }

    $username = sanitize_text_field($_POST['username'] ?? '');
    $email = sanitize_email($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $role = sanitize_text_field($_POST['role'] ?? '');
    
    if (empty($username) || empty($email) || empty($password) || empty($role)) {
        error_log('TMS Create User: Missing required fields');
        wp_send_json(['success' => false, 'data' => ['message' => 'All fields are required.']]);
        return;
    }
    
    $result = tms_create_user($username, $email, $password, $role);
    if ($result['success']) {
        $result['data']['user'] = [
            'id' => $result['data']['user_id'],
            'username' => $username,
            'email' => $email,
            'role' => $role,
        ];
    }
    error_log('TMS Create User Result: ' . print_r($result, true));
    wp_send_json($result);
}

// AJAX handler for updating a user
add_action('wp_ajax_tms_update_user', 'tms_ajax_update_user');
function tms_ajax_update_user() {
    error_log('TMS Update User AJAX called with POST: ' . print_r($_POST, true));
    
    if (!current_user_can('project_manager')) {
        error_log('TMS Update User: Unauthorized');
        wp_send_json(['success' => false, 'data' => ['message' => 'Unauthorized']]);
        return;
    }
    
    $user_id = intval($_POST['user_id'] ?? 0);
    $username = sanitize_text_field($_POST['username'] ?? '');
    $email = sanitize_email($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $role = sanitize_text_field($_POST['role'] ?? '');
    
    if (empty($user_id) || empty($username) || empty($email) || empty($role)) {
        error_log('TMS Update User: Missing required fields');
        wp_send_json(['success' => false, 'data' => ['message' => 'All required fields must be filled.']]);
        return;
    }
    
    $user = get_user_by('ID', $user_id);
    if (!$user) {
        error_log('TMS Update User: User not found');
        wp_send_json(['success' => false, 'data' => ['message' => 'User not found.']]);
        return;
    }
    
    $existing_user_by_username = username_exists($username);
    $existing_user_by_email = email_exists($email);
    if (($existing_user_by_username && $existing_user_by_username != $user_id) || 
        ($existing_user_by_email && $existing_user_by_email != $user_id)) {
        error_log('TMS Update User: Username or email already exists');
        wp_send_json(['success' => false, 'data' => ['message' => 'Username or email already exists.']]);
        return;
    }
    
    $user_data = [
        'ID' => $user_id,
        'user_login' => $username,
        'user_email' => $email,
    ];
    
    if (!empty($password)) {
        $user_data['user_pass'] = $password;
    }

    $result = wp_update_user($user_data);
    if (is_wp_error($result)) {
        error_log('TMS Update User: Error updating user - ' . $result->get_error_message());
        wp_send_json(['success' => false, 'data' => ['message' => $result->get_error_message()]]);
        return;
    }
    
    $wp_user = new WP_User($user_id);
    $wp_user->set_role($role);
    
    wp_send_json([
        'success' => true,
        'data' => [
            'message' => 'User updated successfully.',
            'user' => [
                'id' => $user_id,
                'username' => $username,
                'email' => $email,
                'role' => $role,
            ]
        ]
    ]);
}

// AJAX handler for deleting a user
add_action('wp_ajax_tms_delete_user', 'tms_ajax_delete_user');
function tms_ajax_delete_user() {
    error_log('TMS Delete User AJAX called with POST: ' . print_r($_POST, true));
    
    if (!current_user_can('project_manager')) {
        error_log('TMS Delete User: Unauthorized');
        wp_send_json(['success' => false, 'data' => ['message' => 'Unauthorized']]);
        return;
    }
    
    $user_id = intval($_POST['user_id'] ?? 0);
    
    if (empty($user_id)) {
        error_log('TMS Delete User: Missing user ID');
        wp_send_json(['success' => false, 'data' => ['message' => 'User ID is required.']]);
        return;
    }
    
    $user = get_user_by('ID', $user_id);
    if (!$user) {
        error_log('TMS Delete User: User not found');
        wp_send_json(['success' => false, 'data' => ['message' => 'User not found.']]);
        return;
    }
    
    if ($user_id == get_current_user_id()) {
        error_log('TMS Delete User: Cannot delete current user');
        wp_send_json(['success' => false, 'data' => ['message' => 'You cannot delete your own account.']]);
        return;
    }

    require_once(ABSPATH . 'wp-admin/includes/user.php');
    $result = wp_delete_user($user_id);
    if ($result === false) {
        error_log('TMS Delete User: Error deleting user');
        wp_send_json(['success' => false, 'data' => ['message' => 'Failed to delete user.']]);
        return;
    }

    wp_send_json(['success' => true, 'data' => ['message' => 'User deleted successfully.']]);
}

// AJAX handler for creating a new task
add_action('wp_ajax_tms_create_task', 'tms_ajax_create_task');
function tms_ajax_create_task() {
    error_log('TMS Create Task AJAX called with POST: ' . print_r($_POST, true));
    
    if (!current_user_can('project_manager')) {
        error_log('TMS Create Task: Unauthorized');
        wp_send_json(['success' => false, 'data' => ['message' => 'Unauthorized']]);
        return;
    }

    $title = sanitize_text_field($_POST['title'] ?? '');
    $description = sanitize_textarea_field($_POST['description'] ?? '');
    $assigned_to = intval($_POST['assigned_to'] ?? 0);
    $status = sanitize_text_field($_POST['status'] ?? '');
    $created_by = get_current_user_id();
    
    if (empty($title) || empty($assigned_to) || empty($status)) {
        error_log('TMS Create Task: Missing required fields');
        wp_send_json(['success' => false, 'data' => ['message' => 'All required fields must be filled.']]);
        return;
    }

    $result = tms_create_task($title, $description, $assigned_to, $status, $created_by);
    error_log('TMS Create Task Result: ' . print_r($result, true));
    wp_send_json($result);
}

// AJAX handler for updating task status
add_action('wp_ajax_tms_update_task_status', 'tms_ajax_update_task_status');
function tms_ajax_update_task_status() {
    error_log('TMS Update Task Status AJAX called with POST: ' . print_r($_POST, true));
    
    $task_id = intval($_POST['task_id'] ?? 0);
    $status = sanitize_text_field($_POST['status'] ?? '');
    $user_id = get_current_user_id();

    if (empty($task_id) || empty($status)) {
        error_log('TMS Update Task Status: Missing required fields');
        wp_send_json(['success' => false, 'data' => ['message' => 'Task ID and status are required.']]);
        return;
    }
    
    $result = tms_update_task_status($task_id, $status, $user_id);
    
    $response = [
        'success' => $result['success'],
        'data' => [
            'message' => $result['message'] ?? ($result['success'] ? 'Task status updated successfully.' : 'Failed to update task status.')
        ]
    ];
    error_log('TMS Update Task Status Result: ' . print_r($response, true));
    wp_send_json($response);
}

// AJAX handler for updating task details
add_action('wp_ajax_tms_update_task', 'tms_ajax_update_task');
function tms_ajax_update_task() {
    error_log('TMS Update Task AJAX called with POST: ' . print_r($_POST, true));
    
    if (!current_user_can('project_manager')) {
        error_log('TMS Update Task: Unauthorized');
        wp_send_json(['success' => false, 'data' => ['message' => 'Unauthorized']]);
        return;
    }

    $task_id = intval($_POST['task_id'] ?? 0);
    $title = sanitize_text_field($_POST['title'] ?? '');
    $description = sanitize_textarea_field($_POST['description'] ?? '');
    $assigned_to = intval($_POST['assigned_to'] ?? 0);
    $status = sanitize_text_field($_POST['status'] ?? '');
    
    if (empty($task_id) || empty($title) || empty($assigned_to) || empty($status)) {
        error_log('TMS Update Task: Missing required fields');
        wp_send_json(['success' => false, 'data' => ['message' => 'All required fields must be filled.']]);
        return;
    }
    
    global $wpdb;
    $table_name = $wpdb->prefix . 'tms_tasks';
    $task = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $task_id));
    if (!$task) {
        error_log('TMS Update Task: Task not found');
        wp_send_json(['success' => false, 'data' => ['message' => 'Task not found.']]);
        return;
    }
    
    $result = $wpdb->update(
        $table_name,
        [
            'title' => $title,
            'description' => $description,
            'assigned_to' => $assigned_to,
            'status' => $status,
        ],
        ['id' => $task_id],
        ['%s', '%s', '%d', '%s'],
        ['%d']
    );
    if ($result === false) {
        error_log('TMS Update Task: Database error');
        wp_send_json(['success' => false, 'data' => ['message' => 'Failed to update task.']]);
        return;
    }
    
    wp_send_json([
        'success' => true,
        'data' => [
            'message' => 'Task updated successfully.',
            'task' => [
                'id' => $task_id,
                'title' => $title,
                'description' => $description,
                'assigned_to' => $assigned_to,
                'status' => $status,
            ]
        ]
    ]);
}

// AJAX handler for deleting a task
add_action('wp_ajax_tms_delete_task', 'tms_ajax_delete_task');
function tms_ajax_delete_task() {
    error_log('TMS Delete Task AJAX called with POST: ' . print_r($_POST, true));
    
    if (!current_user_can('project_manager')) {
        error_log('TMS Delete Task: Unauthorized');
        wp_send_json(['success' => false, 'data' => ['message' => 'Unauthorized']]);
        return;
    }
    
    $task_id = intval($_POST['task_id'] ?? 0);
    
    if (empty($task_id)) {
        error_log('TMS Delete Task: Missing task ID');
        wp_send_json(['success' => false, 'data' => ['message' => 'Task ID is required.']]);
        return;
    }
    
    global $wpdb;
    $table_name = $wpdb->prefix . 'tms_tasks';
    $task = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $task_id));
    if (!$task) {
        error_log('TMS Delete Task: Task not found');
        wp_send_json(['success' => false, 'data' => ['message' => 'Task not found.']]);
        return;
    }
    
    $result = $wpdb->delete(
        $table_name,
        ['id' => $task_id],
        ['%d']
    );
    if ($result === false) {
        error_log('TMS Delete Task: Database error');
        wp_send_json(['success' => false, 'data' => ['message' => 'Failed to delete task.']]);
        return;
    }
    
    wp_send_json(['success' => true, 'data' => ['message' => 'Task deleted successfully.']]);
}
?>