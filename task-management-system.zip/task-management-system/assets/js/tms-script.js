jQuery(document).ready(function($) {
    // Handle login form submission
    $('#tms-login-form').on('submit', function(e) {
        e.preventDefault();
        let formData = $(this).serialize() + '&action=tms_login&nonce=' + tmsAjax.nonce;
        $.post(tmsAjax.ajax_url, formData, function(response) {
            console.log('Full AJAX Response:', response);
            if (typeof response === 'string') {
                console.error('Received non-JSON response:', response);
                $('#tms-login-error').text('Server returned an invalid response. Please try again.').show();
                return;
            }
            if (response && typeof response === 'object' && response.success && response.data && response.data.redirect) {
                window.location.href = response.data.redirect;
            } else {
                let errorMessage = (response && response.data && response.data.message) 
                    ? response.data.message 
                    : 'An error occurred during login. Please try again.';
                $('#tms-login-error').text(errorMessage).show();
            }
        }).fail(function(jqXHR, textStatus, errorThrown) {
            console.error('AJAX Error:', textStatus, errorThrown, jqXHR.responseText);
            $('#tms-login-error').text('Failed to connect to the server. Please try again.').show();
        });
    });

    // Handle user creation form submission
    $('#tms-create-user-form').on('submit', function(e) {
        e.preventDefault();
        let formData = $(this).serialize() + '&action=tms_create_user&nonce=' + tmsAjax.nonce;
        $.post(tmsAjax.ajax_url, formData, function(response) {
            console.log('Create User Response:', response);
            if (response && typeof response === 'object' && response.success && response.data && response.data.user) {
                let user = response.data.user;
                let tbody = $('table tbody');
                // Remove "No users" message if present
                if (tbody.find('tr td[colspan="4"]').length > 0) {
                    tbody.empty();
                }
                let newRow = `
                    <tr data-user-id="${user.id}">
                        <td class="border p-2">${user.username}</td>
                        <td class="border p-2">${user.email}</td>
                        <td class="border p-2">${user.role}</td>
                        <td class="border p-2">
                            <button class="tms-edit-user bg-yellow-500 text-white px-2 py-1 rounded hover:bg-yellow-600" 
                                    data-user-id="${user.id}" 
                                    data-username="${user.username}" 
                                    data-email="${user.email}" 
                                    data-role="${user.role}"><span class="screen-reader-text"><?php _e('Edit');?></span> 
                  <svg fill="#fff" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" 
                     width="12" height="12" viewBox="0 0 528.899 528.899"
                     xml:space="preserve">
                     <g>
                        <path d="M328.883,89.125l107.59,107.589l-272.34,272.34L56.604,361.465L328.883,89.125z M518.113,63.177l-47.981-47.981
                           c-18.543-18.543-48.653-18.543-67.259,0l-45.961,45.961l107.59,107.59l53.611-53.611
                           C532.495,100.753,532.495,77.559,518.113,63.177z M0.3,512.69c-1.958,8.812,5.998,16.708,14.811,14.565l119.891-29.069
                           L27.473,390.597L0.3,512.69z"/>
                     </g>
                  </svg></button>
                            <button class="tms-delete-user bg-red-600 text-white px-2 py-1 rounded hover:bg-red-700" 
                                    data-user-id="${user.id}"><span class="screen-reader-text"><?php _e('Delete');?></span>
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                     <path d="M6.99486 7.00636C6.60433 7.39689 6.60433 8.03005 6.99486 8.42058L10.58 12.0057L6.99486 15.5909C6.60433 15.9814 6.60433 16.6146 6.99486 17.0051C7.38538 17.3956 8.01855 17.3956 8.40907 17.0051L11.9942 13.4199L15.5794 17.0051C15.9699 17.3956 16.6031 17.3956 16.9936 17.0051C17.3841 16.6146 17.3841 15.9814 16.9936 15.5909L13.4084 12.0057L16.9936 8.42059C17.3841 8.03007 17.3841 7.3969 16.9936 7.00638C16.603 6.61585 15.9699 6.61585 15.5794 7.00638L11.9942 10.5915L8.40907 7.00636C8.01855 6.61584 7.38538 6.61584 6.99486 7.00636Z" fill="#fff"/>
                  </svg></button>
                        </td>
                    </tr>`;
                tbody.append(newRow);
                $('#tms-user-message').text('User has been added').addClass('text-green-600').show();
                $('#tms-create-user-form')[0].reset();
            } else {
                let errorMessage = (response && response.data && response.data.message) 
                    ? response.data.message 
                    : 'Failed to create user. Please try again.';
                $('#tms-user-message').text(errorMessage).addClass('text-red-600').show();
            }
            setTimeout(() => {
                $('#tms-user-message').fadeOut();
            }, 3000);
        }).fail(function(jqXHR, textStatus, errorThrown) {
            console.error('Create User AJAX Error:', textStatus, errorThrown, jqXHR.responseText);
            $('#tms-user-message').text('Failed to connect to the server. Please try again.').addClass('text-red-600').show();
            setTimeout(() => {
                $('#tms-user-message').fadeOut();
            }, 3000);
        });
    });

    // Handle task creation form submission
    $('#tms-create-task-form').on('submit', function(e) {
        e.preventDefault();
        let formData = $(this).serialize() + '&action=tms_create_task&nonce=' + tmsAjax.nonce;
        $.post(tmsAjax.ajax_url, formData, function(response) {
            console.log('Create Task Response:', response);
            if (response && typeof response === 'object' && response.success) {
                $('#tms-task-message').text('Task has been added').addClass('text-green-600').show();
                $('#tms-create-task-form')[0].reset();
            } else {
                let errorMessage = (response && response.data && response.data.message) 
                    ? response.data.message 
                    : 'Failed to create task. Please try again.';
                $('#tms-task-message').text(errorMessage).addClass('text-red-600').show();
            }
            setTimeout(() => {
                $('#tms-task-message').fadeOut();
            }, 3000);
        }).fail(function(jqXHR, textStatus, errorThrown) {
            console.error('Create Task AJAX Error:', textStatus, errorThrown, jqXHR.responseText);
            $('#tms-task-message').text('Failed to connect to the server. Please try again.').addClass('text-red-600').show();
            setTimeout(() => {
                $('#tms-task-message').fadeOut();
            }, 3000);
        });
    });

    // Handle task status update
    $('.tms-update-status').on('change', function() {
        let taskId = $(this).data('task-id');
        let status = $(this).val();
        let $select = $(this);
        $.post(tmsAjax.ajax_url, {
            action: 'tms_update_task_status',
            task_id: taskId,
            status: status,
            nonce: tmsAjax.nonce
        }, function(response) {
            console.log('Update Task Status Response:', response);
            let message = (response && response.data && response.data.message) 
                ? response.data.message 
                : (response && response.message) 
                ? response.message 
                : (response.success ? 'Task status updated successfully.' : 'Failed to update task status.');
            let messageClass = response.success ? 'text-green-600' : 'text-red-600';
            $('#tms-task-message-' + taskId).text(message).addClass(messageClass).show();
            if (response.success) {
                // Remove existing status classes and add new one
                $select.removeClass('status-open status-in-progress status-in-review status-pending status-completed');
                $select.addClass('status-' + status);
            }
            setTimeout(() => {
                $('#tms-task-message-' + taskId).fadeOut();
            }, 3000);
        }).fail(function(jqXHR, textStatus, errorThrown) {
            console.error('Update Task Status AJAX Error:', textStatus, errorThrown, jqXHR.responseText);
            $('#tms-task-message-' + taskId).text('Failed to connect to the server. Please try again.').addClass('text-red-600').show();
            setTimeout(() => {
                $('#tms-task-message-' + taskId).fadeOut();
            }, 3000);
        });
    });

    // Handle edit task button click
    $(document).on('click', '.tms-edit-task', function() {
        let taskId = $(this).data('task-id');
        let title = $(this).data('title');
        let description = $(this).data('description');
        let assignedTo = $(this).data('assigned-to');
        let status = $(this).data('status');
        $('#edit-task-id').val(taskId);
        $('#edit-title').val(title);
        $('#edit-description').val(description);
        $('#edit-assigned-to').val(assignedTo);
        $('#edit-status').val(status);
        $('#tms-edit-task-modal').removeClass('hidden');
    });

    // Handle cancel edit task
    $('#tms-cancel-edit-task').on('click', function() {
        $('#tms-edit-task-modal').addClass('hidden');
        $('#tms-edit-task-form')[0].reset();
        $('#tms-edit-task-message').addClass('hidden');
    });

    // Handle edit task form submission
    $('#tms-edit-task-form').on('submit', function(e) {
        e.preventDefault();
        let formData = $(this).serialize() + '&action=tms_update_task&nonce=' + tmsAjax.nonce;
        $.post(tmsAjax.ajax_url, formData, function(response) {
            console.log('Update Task Response:', response);
            if (response && typeof response === 'object' && response.success && response.data && response.data.task) {
                let task = response.data.task;
                let assignedUser = $('#edit-assigned-to option[value="' + task.assigned_to + '"]').text();
                let row = $(`tr[data-task-id="${task.id}"]`);
                row.find('td:eq(0)').text(task.title);
                row.find('td:eq(1)').text(task.description);
                row.find('td:eq(2)').text(assignedUser || 'Unassigned');
                row.find('td:eq(3) select').val(task.status);
                // Update status class on select after edit
                row.find('td:eq(3) select').removeClass('status-open status-in-progress status-in-review status-pending status-completed');
                row.find('td:eq(3) select').addClass('status-' + task.status);
                $('#tms-edit-task-message').text('Task has been updated').addClass('text-green-600').show();
                $('#tms-edit-task-form')[0].reset();
                $('#tms-edit-task-modal').addClass('hidden');
            } else {
                let errorMessage = (response && response.data && response.data.message) 
                    ? response.data.message 
                    : 'Failed to update task. Please try again.';
                $('#tms-edit-task-message').text(errorMessage).addClass('text-red-600').show();
            }
            setTimeout(() => {
                $('#tms-edit-task-message').fadeOut();
            }, 3000);
        }).fail(function(jqXHR, textStatus, errorThrown) {
            console.error('Update Task AJAX Error:', textStatus, errorThrown, jqXHR.responseText);
            $('#tms-edit-task-message').text('Failed to connect to the server. Please try again.').addClass('text-red-600').show();
            setTimeout(() => {
                $('#tms-edit-task-message').fadeOut();
            }, 3000);
        });
    });

    // Handle delete task button click
    $(document).on('click', '.tms-delete-task', function() {
        if (!confirm('Are you sure you want to delete this task?')) {
            return;
        }
        let taskId = $(this).data('task-id');
        $.post(tmsAjax.ajax_url, {
            action: 'tms_delete_task',
            task_id: taskId,
            nonce: tmsAjax.nonce
        }, function(response) {
            console.log('Delete Task Response:', response);
            if (response && typeof response === 'object' && response.success) {
                // Remove the task row
                $(`tr[data-task-id="${taskId}"]`).remove();
                // Display success message
                let message = $('<p class="tms-temp-message text-green-600 text-center mt-2">Task has been deleted</p>');
                $('table').before(message);
                setTimeout(() => {
                    message.fadeOut(() => message.remove());
                }, 3000);
                // Check if table is empty and append "No tasks added here" if needed
                let tbody = $('table tbody');
                if (tbody.find('tr').length === 0 || tbody.find('tr').find('td[colspan="5"]').length > 0) {
                    tbody.empty(); // Clear any existing "No tasks" row to avoid duplicates
                    tbody.append('<tr><td colspan="5" class="border p-4 text-center text-gray-500">No tasks added here</td></tr>');
                }
            } else {
                let errorMessage = (response && response.data && response.data.message) 
                    ? response.data.message 
                    : 'Failed to delete task. Please try again.';
                let error = $('<p class="tms-temp-message text-red-600 text-center mt-2">' + errorMessage + '</p>');
                $('table').before(error);
                setTimeout(() => {
                    error.fadeOut(() => error.remove());
                }, 3000);
            }
        }).fail(function(jqXHR, textStatus, errorThrown) {
            console.error('Delete Task AJAX Error:', textStatus, errorThrown, jqXHR.responseText);
            let error = $('<p class="tms-temp-message text-red-600 text-center mt-2">Failed to connect to the server. Please try again.</p>');
            $('table').before(error);
            setTimeout(() => {
                error.fadeOut(() => error.remove());
            }, 3000);
        });
    });

    // Handle edit user button click
    $(document).on('click', '.tms-edit-user', function() {
        let userId = $(this).data('user-id');
        let username = $(this).data('username');
        let email = $(this).data('email');
        let role = $(this).data('role');
        $('#edit-user-id').val(userId);
        $('#edit-username').val(username);
        $('#edit-email').val(email);
        $('#edit-role').val(role);
        $('#tms-edit-user-modal').removeClass('hidden');
    });

    // Handle cancel edit user
    $('#tms-cancel-edit-user').on('click', function() {
        $('#tms-edit-user-modal').addClass('hidden');
        $('#tms-edit-user-form')[0].reset();
        $('#tms-edit-user-message').addClass('hidden');
    });

    // Handle edit user form submission
    $('#tms-edit-user-form').on('submit', function(e) {
        e.preventDefault();
        let formData = $(this).serialize() + '&action=tms_update_user&nonce=' + tmsAjax.nonce;
        $.post(tmsAjax.ajax_url, formData, function(response) {
            console.log('Update User Response:', response);
            if (response && typeof response === 'object' && response.success && response.data && response.data.user) {
                let user = response.data.user;
                let row = $(`tr[data-user-id="${user.id}"]`);
                row.find('td:eq(0)').text(user.username);
                row.find('td:eq(1)').text(user.email);
                row.find('td:eq(2)').text(user.role);
                row.find('td:eq(3) button.tms-edit-user')
                    .data('username', user.username)
                    .data('email', user.email)
                    .data('role', user.role);
                $('#tms-edit-user-message').text('User has been updated').addClass('text-green-600').show();
                $('#tms-edit-user-form')[0].reset();
                $('#tms-edit-user-modal').addClass('hidden');
            } else {
                let errorMessage = (response && response.data && response.data.message) 
                    ? response.data.message 
                    : 'Failed to update user. Please try again.';
                $('#tms-edit-user-message').text(errorMessage).addClass('text-red-600').show();
            }
            setTimeout(() => {
                $('#tms-edit-user-message').fadeOut();
            }, 3000);
        }).fail(function(jqXHR, textStatus, errorThrown) {
            console.error('Update User AJAX Error:', textStatus, errorThrown, jqXHR.responseText);
            $('#tms-edit-user-message').text('Failed to connect to the server. Please try again.').addClass('text-red-600').show();
            setTimeout(() => {
                $('#tms-edit-user-message').fadeOut();
            }, 3000);
        });
    });

    // Handle delete user button click
    $(document).on('click', '.tms-delete-user', function() {
        if (!confirm('Are you sure you want to delete this user?')) {
            return;
        }
        let userId = $(this).data('user-id');
        $.post(tmsAjax.ajax_url, {
            action: 'tms_delete_user',
            user_id: userId,
            nonce: tmsAjax.nonce
        }, function(response) {
            console.log('Delete User Response:', response);
            if (response && typeof response === 'object' && response.success) {
                // Remove the user row
                $(`tr[data-user-id="${userId}"]`).remove();
                // Display success message
                let message = $('<p class="tms-temp-message text-green-600 text-center mt-2">User has been deleted</p>');
                $('table').before(message);
                setTimeout(() => {
                    message.fadeOut(() => message.remove());
                }, 3000);
                // Check if table is empty and append "No users added here" if needed
                let tbody = $('table tbody');
                if (tbody.find('tr').length === 0 || tbody.find('tr').find('td[colspan="4"]').length > 0) {
                    tbody.empty(); // Clear any existing "No users" row to avoid duplicates
                    tbody.append('<tr><td colspan="4" class="border p-4 text-center text-gray-500">No users added here</td></tr>');
                }
            } else {
                let errorMessage = (response && response.data && response.data.message) 
                    ? response.data.message 
                    : 'Failed to delete user. Please try again.';
                let error = $('<p class="tms-temp-message text-red-600 text-center mt-2">' + errorMessage + '</p>');
                $('table').before(error);
                setTimeout(() => {
                    error.fadeOut(() => error.remove());
                }, 3000);
            }
        }).fail(function(jqXHR, textStatus, errorThrown) {
            console.error('Delete User AJAX Error:', textStatus, errorThrown, jqXHR.responseText);
            let error = $('<p class="tms-temp-message text-red-600 text-center mt-2">Failed to connect to the server. Please try again.</p>');
            $('table').before(error);
            setTimeout(() => {
                error.fadeOut(() => error.remove());
            }, 3000);
        });
    });
});