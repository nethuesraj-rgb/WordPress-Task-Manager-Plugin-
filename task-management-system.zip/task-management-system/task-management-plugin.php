<?php
/*
Plugin Name: Task Management System
Description: A frontend-only task management system with custom roles and shortcode-based screens.
Version: 1.0
Author: Raj Yadav
*/

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('TMS_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('TMS_PLUGIN_URL', plugin_dir_url(__FILE__));

// Include required files
require_once TMS_PLUGIN_DIR . 'inc/task-management-functions.php';
require_once TMS_PLUGIN_DIR . 'inc/task-management-ajax.php';
require_once TMS_PLUGIN_DIR . 'inc/task-management-shortcodes.php';

// Activation hook to create database table and roles
register_activation_hook(__FILE__, 'tms_activate_plugin');
function tms_activate_plugin() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'tms_tasks';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        title varchar(255) NOT NULL,
        description text,
        status varchar(20) NOT NULL DEFAULT 'open',
        assigned_to bigint(20) NOT NULL,
        created_by bigint(20) NOT NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    // Add custom roles
    add_role('project_manager', 'Project Manager', [
        'read' => true,
        'manage_tasks' => true,
        'manage_users' => true,
    ]);
    add_role('team_member', 'Team Member', [
        'read' => true,
        'manage_own_tasks' => true,
    ]);
}

// Deactivation hook to remove roles
register_deactivation_hook(__FILE__, 'tms_deactivate_plugin');
function tms_deactivate_plugin() {
    remove_role('project_manager');
    remove_role('team_member');
}

// Prevent wp-admin and wp-login.php access for non-admins
add_action('init', 'tms_restrict_admin_access');
function tms_restrict_admin_access() {
    if (wp_doing_ajax()) {
        return;
    }
    if (isset($_GET['action']) && $_GET['action'] === 'logout') {
        return;
    }
    if ((is_admin() || in_array($GLOBALS['pagenow'], ['wp-login.php'])) && !current_user_can('administrator')) {
        wp_redirect(home_url());
        exit;
    }
}

// Enqueue scripts and styles
add_action('wp_enqueue_scripts', 'tms_enqueue_assets');
function tms_enqueue_assets() {
    wp_enqueue_style('tms-tailwind', plugins_url('assets/css/tailwind.min.css', __FILE__), [], '2.2.19');
    wp_enqueue_style('tms-style', plugins_url('assets/css/tms-style.css', __FILE__), [], '1.0');
    wp_enqueue_script('jquery');
    wp_enqueue_script('tms-script', TMS_PLUGIN_URL . 'assets/js/tms-script.js', ['jquery'], '1.0', true);
    $nonce = wp_create_nonce('tms_nonce');
    error_log('TMS Nonce: ' . $nonce);
    wp_localize_script('tms-script', 'tmsAjax', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => $nonce,
    ]);
}

// Create plugin assets directory
add_action('init', 'tms_create_assets_directory');
function tms_create_assets_directory() {
    $upload_dir = wp_upload_dir();
    $assets_dir = $upload_dir['basedir'] . '/tms-assets';
    if (!file_exists($assets_dir)) {
        wp_mkdir_p($assets_dir);
    }
}
?>
